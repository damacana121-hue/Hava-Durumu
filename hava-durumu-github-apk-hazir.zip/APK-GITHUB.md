# APK oluşturma

GitHub'a bu projenin içindeki dosyaları yükledikten sonra:
1. GitHub -> Actions
2. `Build APK`
3. `Run workflow`

Build tamamlanınca `Hava-Durumu-debug-apk` adlı artifact içinden APK indirilebilir.
