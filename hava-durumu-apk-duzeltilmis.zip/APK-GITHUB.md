# APK oluşturma

Bu sürüm KSP'yi Kotlin 2.2.10 ile uyumlu `2.2.10-2.0.2` sürümüne sabitler.
GitHub Actions JDK 17 + Gradle 9.3.1 ile debug APK üretir.

GitHub → Actions → Build APK → Run workflow.
