package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.BeaufortScale
import com.example.data.model.TemperatureUnit
import com.example.data.model.WindDetails
import com.example.data.model.WindUnit
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Hava Durumu", appName)
    }

    @Test
    fun `test beaufort scale calculations`() {
        val calm = BeaufortScale.fromSpeedKmh(1.5)
        assertEquals(BeaufortScale.CALM, calm)

        val freshBreeze = BeaufortScale.fromSpeedKmh(32.0)
        assertEquals(BeaufortScale.FRESH_BREEZE, freshBreeze)

        val gale = BeaufortScale.fromSpeedKmh(65.0)
        assertEquals(BeaufortScale.GALE, gale)
    }

    @Test
    fun `test temperature formatting`() {
        val celsiusStr = TemperatureUnit.CELSIUS.format(23.4)
        assertEquals("23°C", celsiusStr)

        val fahrStr = TemperatureUnit.FAHRENHEIT.format(20.0)
        assertEquals("68°F", fahrStr)
    }

    @Test
    fun `test wind details cardinal direction`() {
        val windNorth = WindDetails(15.0, 0, 20.0, BeaufortScale.GENTLE_BREEZE)
        assertEquals("Kuzey (K)", windNorth.cardinalDirectionLocalized(isTurkish = true))
        assertEquals("North (N)", windNorth.cardinalDirectionLocalized(isTurkish = false))

        val windEast = WindDetails(15.0, 90, 20.0, BeaufortScale.GENTLE_BREEZE)
        assertEquals("Doğu (D)", windEast.cardinalDirectionLocalized(isTurkish = true))
    }
}
