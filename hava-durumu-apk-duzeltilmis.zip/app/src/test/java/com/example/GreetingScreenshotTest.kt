package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.model.AppLanguage
import com.example.data.model.BeaufortScale
import com.example.data.model.WindDetails
import com.example.data.model.WindUnit
import com.example.ui.components.WindCompassCard
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [36])
class GreetingScreenshotTest {

    @get:Rule val composeTestRule = createComposeRule()

    @Test
    fun greeting_screenshot() {
        val windDetails = WindDetails(
            speedKmh = 24.0,
            directionDegrees = 45,
            gustKmh = 35.0,
            beaufortScale = BeaufortScale.MODERATE_BREEZE
        )

        composeTestRule.setContent {
            MyApplicationTheme {
                WindCompassCard(
                    windDetails = windDetails,
                    windUnit = WindUnit.KMH,
                    language = AppLanguage.TURKISH
                )
            }
        }

        composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
    }
}
