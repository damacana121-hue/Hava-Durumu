package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.SavedLocationEntity
import com.example.data.local.SevereAlertEntity
import com.example.data.local.WeatherCacheEntity
import com.example.data.model.AlertSeverity
import com.example.data.model.BeaufortScale
import com.example.data.model.DailyForecast
import com.example.data.model.HourlyForecast
import com.example.data.model.LocationItem
import com.example.data.model.SevereAlert
import com.example.data.model.WeatherInfo
import com.example.data.model.WindDetails
import com.example.data.network.ApiClient
import com.example.notifications.WeatherNotificationManager
import com.example.ui.util.WeatherCodeHelper
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WeatherRepository(
    private val database: AppDatabase,
    private val notificationManager: WeatherNotificationManager
) {
    private val weatherDao = database.weatherDao()
    private val apiService = ApiClient.weatherService
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    private val hourlyListAdapter = moshi.adapter<List<HourlyForecast>>(
        Types.newParameterizedType(List::class.java, HourlyForecast::class.java)
    )
    private val dailyListAdapter = moshi.adapter<List<DailyForecast>>(
        Types.newParameterizedType(List::class.java, DailyForecast::class.java)
    )
    private val alertsListAdapter = moshi.adapter<List<SevereAlert>>(
        Types.newParameterizedType(List::class.java, SevereAlert::class.java)
    )

    val savedLocationsFlow: Flow<List<LocationItem>> = weatherDao.getSavedLocations().map { list ->
        list.map { entity ->
            LocationItem(
                id = entity.id,
                name = entity.name,
                country = entity.country,
                admin1 = entity.admin1,
                latitude = entity.latitude,
                longitude = entity.longitude,
                isFavorite = entity.isFavorite,
                isCurrentGps = entity.isDefault
            )
        }
    }

    val alertHistoryFlow: Flow<List<SevereAlert>> = weatherDao.getAllAlerts().map { list ->
        list.map { entity ->
            val severity = when (entity.severityLevel) {
                "DANGER" -> AlertSeverity.DANGER
                "WARNING" -> AlertSeverity.WARNING
                "ADVISORY" -> AlertSeverity.ADVISORY
                else -> AlertSeverity.INFO
            }
            SevereAlert(
                id = entity.alertId,
                titleTr = entity.titleTr,
                titleEn = entity.titleEn,
                messageTr = entity.messageTr,
                messageEn = entity.messageEn,
                severity = severity,
                timestamp = entity.timestamp,
                isRead = entity.isRead,
                sourceLocation = entity.locationName
            )
        }
    }

    suspend fun getInitialLocation(): LocationItem {
        return withContext(Dispatchers.IO) {
            // Istanbul default location
            LocationItem(
                id = 1,
                name = "İstanbul",
                country = "Türkiye",
                admin1 = "Marmara",
                latitude = 41.0082,
                longitude = 28.9784,
                isFavorite = true,
                isCurrentGps = true
            )
        }
    }

    suspend fun fetchWeather(
        location: LocationItem,
        windAlertThresholdKmh: Double = 45.0,
        notificationsEnabled: Boolean = true,
        isTurkish: Boolean = true
    ): Result<WeatherInfo> = withContext(Dispatchers.IO) {
        val locationKey = "${String.format(Locale.US, "%.3f", location.latitude)}_${String.format(Locale.US, "%.3f", location.longitude)}"
        
        try {
            val response = apiService.getForecast(
                latitude = location.latitude,
                longitude = location.longitude
            )

            val current = response.current
            val currentTemp = current?.temperature2m ?: 21.0
            val feelsLike = current?.apparentTemperature ?: currentTemp
            val weatherCode = current?.weatherCode ?: 0
            val windSpeed = current?.windSpeed10m ?: 14.0
            val windDir = current?.windDirection10m ?: 45
            val windGust = current?.windGusts10m ?: (windSpeed * 1.35)
            val humidity = current?.relativeHumidity2m ?: 55
            val pressure = current?.surfacePressure ?: 1013.2
            val precip = current?.precipitation ?: 0.0

            val beaufort = BeaufortScale.fromSpeedKmh(windSpeed)
            val windDetails = WindDetails(
                speedKmh = windSpeed,
                directionDegrees = windDir,
                gustKmh = windGust,
                beaufortScale = beaufort
            )

            val conditionDisplay = WeatherCodeHelper.getDisplay(weatherCode)

            // Parse hourly forecasts (next 24 hours)
            val hourlyList = mutableListOf<HourlyForecast>()
            val hourlyTimes = response.hourly?.time ?: emptyList()
            val hourlyTemps = response.hourly?.temperature2m ?: emptyList()
            val hourlyCodes = response.hourly?.weatherCode ?: emptyList()
            val hourlyPrecip = response.hourly?.precipitationProbability ?: emptyList()
            val hourlyWinds = response.hourly?.windSpeed10m ?: emptyList()
            val hourlyDirs = response.hourly?.windDirection10m ?: emptyList()

            val maxHourly = minOf(24, hourlyTimes.size)
            if (maxHourly > 0) {
                for (i in 0 until maxHourly) {
                    val rawTime = hourlyTimes.getOrNull(i) ?: ""
                    val hourLabel = if (rawTime.contains("T")) {
                        rawTime.substringAfter("T").take(5)
                    } else {
                        String.format(Locale.US, "%02d:00", i)
                    }
                    hourlyList.add(
                        HourlyForecast(
                            timeLabel = hourLabel,
                            temperature = hourlyTemps.getOrNull(i) ?: currentTemp,
                            weatherCode = hourlyCodes.getOrNull(i) ?: weatherCode,
                            precipitationProbability = hourlyPrecip.getOrNull(i) ?: 0,
                            windSpeedKmh = hourlyWinds.getOrNull(i) ?: windSpeed,
                            windDirectionDegrees = hourlyDirs.getOrNull(i) ?: windDir
                        )
                    )
                }
            } else {
                // Generate 24-hour forecast from current
                for (i in 0 until 24) {
                    val tempVariation = Math.sin((i - 6) * Math.PI / 12) * 4.0
                    hourlyList.add(
                        HourlyForecast(
                            timeLabel = String.format(Locale.US, "%02d:00", i),
                            temperature = currentTemp + tempVariation,
                            weatherCode = weatherCode,
                            precipitationProbability = if (precip > 0) 40 else 5,
                            windSpeedKmh = (windSpeed + (i % 5)).coerceAtLeast(0.0),
                            windDirectionDegrees = (windDir + (i * 10)) % 360
                        )
                    )
                }
            }

            // Parse daily forecasts (7 days)
            val dailyList = mutableListOf<DailyForecast>()
            val dailyTimes = response.daily?.time ?: emptyList()
            val dailyCodes = response.daily?.weatherCode ?: emptyList()
            val dailyMax = response.daily?.temperature2mMax ?: emptyList()
            val dailyMin = response.daily?.temperature2mMin ?: emptyList()
            val dailyPrecipProb = response.daily?.precipitationProbabilityMax ?: emptyList()
            val dailyPrecipSum = response.daily?.precipitationSum ?: emptyList()
            val dailyMaxWind = response.daily?.windSpeed10mMax ?: emptyList()
            val dailyMaxGust = response.daily?.windGusts10mMax ?: emptyList()
            val dailyUv = response.daily?.uvIndexMax ?: emptyList()
            val dailySunrise = response.daily?.sunrise ?: emptyList()
            val dailySunset = response.daily?.sunset ?: emptyList()

            val daysCount = minOf(7, dailyTimes.size)
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val trDayFormat = SimpleDateFormat("EEEE", Locale("tr", "TR"))
            val enDayFormat = SimpleDateFormat("EEEE", Locale.US)

            if (daysCount > 0) {
                for (i in 0 until daysCount) {
                    val dateStr = dailyTimes.getOrNull(i) ?: ""
                    var trLabel = if (i == 0) "Bugün" else if (i == 1) "Yarın" else dateStr
                    var enLabel = if (i == 0) "Today" else if (i == 1) "Tomorrow" else dateStr

                    try {
                        val parsedDate = dateFormat.parse(dateStr)
                        if (parsedDate != null && i > 1) {
                            val rawTr = trDayFormat.format(parsedDate)
                            val rawEn = enDayFormat.format(parsedDate)
                            trLabel = rawTr.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("tr", "TR")) else it.toString() }
                            enLabel = rawEn.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString() }
                        }
                    } catch (_: Exception) {}

                    val srRaw = dailySunrise.getOrNull(i) ?: ""
                    val ssRaw = dailySunset.getOrNull(i) ?: ""
                    val srClean = if (srRaw.contains("T")) srRaw.substringAfter("T").take(5) else "06:15"
                    val ssClean = if (ssRaw.contains("T")) ssRaw.substringAfter("T").take(5) else "19:45"

                    dailyList.add(
                        DailyForecast(
                            dateLabelTr = trLabel,
                            dateLabelEn = enLabel,
                            weatherCode = dailyCodes.getOrNull(i) ?: weatherCode,
                            maxTemp = dailyMax.getOrNull(i) ?: (currentTemp + 3),
                            minTemp = dailyMin.getOrNull(i) ?: (currentTemp - 4),
                            precipitationProbability = dailyPrecipProb.getOrNull(i) ?: 10,
                            precipitationSumMm = dailyPrecipSum.getOrNull(i) ?: 0.0,
                            maxWindSpeedKmh = dailyMaxWind.getOrNull(i) ?: windSpeed,
                            maxGustKmh = dailyMaxGust.getOrNull(i) ?: (windSpeed * 1.3),
                            uvIndex = dailyUv.getOrNull(i) ?: 5.2,
                            sunrise = srClean,
                            sunset = ssClean
                        )
                    )
                }
            } else {
                val dayNamesTr = listOf("Bugün", "Yarın", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar")
                val dayNamesEn = listOf("Today", "Tomorrow", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
                for (i in 0 until 7) {
                    dailyList.add(
                        DailyForecast(
                            dateLabelTr = dayNamesTr.getOrElse(i) { "Gün ${i + 1}" },
                            dateLabelEn = dayNamesEn.getOrElse(i) { "Day ${i + 1}" },
                            weatherCode = if (i % 3 == 0) weatherCode else if (i % 3 == 1) 2 else 0,
                            maxTemp = currentTemp + 2 + (i % 3),
                            minTemp = currentTemp - 4 + (i % 2),
                            precipitationProbability = (i * 12) % 50,
                            precipitationSumMm = if (i == 2) 2.4 else 0.0,
                            maxWindSpeedKmh = windSpeed + (i % 4),
                            maxGustKmh = windGust + (i % 5),
                            uvIndex = 5.0 + (i % 2),
                            sunrise = "06:15",
                            sunset = "19:45"
                        )
                    )
                }
            }

            // Severe weather warnings detection
            val activeAlerts = mutableListOf<SevereAlert>()

            // 1. Gale / High Wind Warning
            if (windSpeed >= windAlertThresholdKmh || windGust >= (windAlertThresholdKmh * 1.2)) {
                val severity = if (windSpeed >= 75 || windGust >= 90) AlertSeverity.DANGER else AlertSeverity.WARNING
                val alert = SevereAlert(
                    id = "wind_alert_${location.name}_${System.currentTimeMillis() / 3600000}",
                    titleTr = "Kuvvetli Rüzgar ve Fırtına Uyarısı (${String.format("%.0f", windSpeed)} km/s)",
                    titleEn = "High Wind & Gale Warning (${String.format("%.0f", windSpeed)} km/h)",
                    messageTr = "${location.name} genelinde rüzgar hızı ${String.format("%.0f", windSpeed)} km/s ve hamleler ${String.format("%.0f", windGust)} km/s seviyesine ulaştı. Çatı uçması, ağaç devrilmesi ve ulaşımda aksamalara karşı dikkatli olunmalıdır.",
                    messageEn = "Wind speeds reaching ${String.format("%.0f", windSpeed)} km/h with gusts up to ${String.format("%.0f", windGust)} km/h in ${location.name}. Caution advised against flying debris and travel disruptions.",
                    severity = severity,
                    sourceLocation = location.name
                )
                activeAlerts.add(alert)

                // Dispatch notification
                if (notificationsEnabled) {
                    notificationManager.sendSevereAlertNotification(alert, isTurkish)
                }

                // Cache in database
                weatherDao.insertAlert(
                    SevereAlertEntity(
                        alertId = alert.id,
                        locationName = location.name,
                        titleTr = alert.titleTr,
                        titleEn = alert.titleEn,
                        messageTr = alert.messageTr,
                        messageEn = alert.messageEn,
                        severityLevel = severity.name
                    )
                )
            }

            // 2. Thunderstorm / Extreme Rain warning
            if (weatherCode in listOf(95, 96, 99)) {
                val alert = SevereAlert(
                    id = "storm_alert_${location.name}_${System.currentTimeMillis() / 3600000}",
                    titleTr = "Gök Gürültülü Şiddetli Fırtına & Yıldırım Uyarısı",
                    titleEn = "Severe Thunderstorm & Lightning Warning",
                    messageTr = "${location.name} çevresinde kuvvetli gök gürültülü sağanak ve yerel dolu yağışı bekleniyor. Açık alanlarda bulunmaktan kaçının.",
                    messageEn = "Severe thunderstorm and possible hail activity reported in ${location.name}. Seek indoor shelter.",
                    severity = AlertSeverity.WARNING,
                    sourceLocation = location.name
                )
                activeAlerts.add(alert)

                if (notificationsEnabled) {
                    notificationManager.sendSevereAlertNotification(alert, isTurkish)
                }
            }

            // 3. Extreme Heat or Frost
            if (currentTemp >= 36.0) {
                val alert = SevereAlert(
                    id = "heat_alert_${location.name}_${System.currentTimeMillis() / 3600000}",
                    titleTr = "Aşırı Sıcaklık ve Güneş Çarpması Uyarısı (${String.format("%.0f", currentTemp)}°C)",
                    titleEn = "Extreme Heat Advisory (${String.format("%.0f", currentTemp)}°C)",
                    messageTr = "Günün en sıcak saatlerinde doğrudan güneş ışığına maruz kalmamaya özen gösterin. Bol sıvı tüketin.",
                    messageEn = "High temperatures may cause heat stroke. Stay hydrated and avoid direct midday sunlight.",
                    severity = AlertSeverity.ADVISORY,
                    sourceLocation = location.name
                )
                activeAlerts.add(alert)
            } else if (currentTemp <= 0.0) {
                val alert = SevereAlert(
                    id = "frost_alert_${location.name}_${System.currentTimeMillis() / 3600000}",
                    titleTr = "Buzlanma ve Don Uyarısı (${String.format("%.0f", currentTemp)}°C)",
                    titleEn = "Frost & Ice Advisory (${String.format("%.0f", currentTemp)}°C)",
                    messageTr = "Yollarda ve kaldırımlarda gizli buzlanma riski. Sürücülerin ve yayaların tedbirli olması önerilir.",
                    messageEn = "Freezing temperatures may cause black ice on roads. Exercise caution.",
                    severity = AlertSeverity.ADVISORY,
                    sourceLocation = location.name
                )
                activeAlerts.add(alert)
            }

            val weatherInfo = WeatherInfo(
                cityName = location.name,
                country = location.country,
                latitude = location.latitude,
                longitude = location.longitude,
                currentTemp = currentTemp,
                feelsLikeTemp = feelsLike,
                weatherCode = weatherCode,
                weatherDescriptionTr = conditionDisplay.descriptionTr,
                weatherDescriptionEn = conditionDisplay.descriptionEn,
                humidity = humidity,
                surfacePressureHpa = pressure,
                precipitationMm = precip,
                windDetails = windDetails,
                hourlyForecasts = hourlyList,
                dailyForecasts = dailyList,
                activeAlerts = activeAlerts,
                lastUpdatedTimestamp = System.currentTimeMillis(),
                isOfflineCached = false
            )

            // Save to Room cache for offline usage
            try {
                weatherDao.insertCachedWeather(
                    WeatherCacheEntity(
                        locationKey = locationKey,
                        cityName = location.name,
                        country = location.country,
                        latitude = location.latitude,
                        longitude = location.longitude,
                        currentTemp = currentTemp,
                        feelsLikeTemp = feelsLike,
                        weatherCode = weatherCode,
                        weatherDescriptionTr = conditionDisplay.descriptionTr,
                        weatherDescriptionEn = conditionDisplay.descriptionEn,
                        humidity = humidity,
                        surfacePressureHpa = pressure,
                        precipitationMm = precip,
                        windSpeedKmh = windSpeed,
                        windDirectionDegrees = windDir,
                        windGustKmh = windGust,
                        hourlyJson = hourlyListAdapter.toJson(hourlyList),
                        dailyJson = dailyListAdapter.toJson(dailyList),
                        alertsJson = alertsListAdapter.toJson(activeAlerts),
                        cachedTimestamp = System.currentTimeMillis()
                    )
                )
            } catch (_: Exception) {}

            Result.success(weatherInfo)
        } catch (e: Exception) {
            // Check Room Database cache for offline recovery
            val cached = weatherDao.getCachedWeather(locationKey)
            if (cached != null) {
                val parsedHourly = try {
                    hourlyListAdapter.fromJson(cached.hourlyJson) ?: emptyList()
                } catch (_: Exception) { emptyList() }

                val parsedDaily = try {
                    dailyListAdapter.fromJson(cached.dailyJson) ?: emptyList()
                } catch (_: Exception) { emptyList() }

                val parsedAlerts = try {
                    alertsListAdapter.fromJson(cached.alertsJson) ?: emptyList()
                } catch (_: Exception) { emptyList() }

                val beaufort = BeaufortScale.fromSpeedKmh(cached.windSpeedKmh)
                val windDetails = WindDetails(
                    speedKmh = cached.windSpeedKmh,
                    directionDegrees = cached.windDirectionDegrees,
                    gustKmh = cached.windGustKmh,
                    beaufortScale = beaufort
                )

                val cachedInfo = WeatherInfo(
                    cityName = cached.cityName,
                    country = cached.country,
                    latitude = cached.latitude,
                    longitude = cached.longitude,
                    currentTemp = cached.currentTemp,
                    feelsLikeTemp = cached.feelsLikeTemp,
                    weatherCode = cached.weatherCode,
                    weatherDescriptionTr = cached.weatherDescriptionTr,
                    weatherDescriptionEn = cached.weatherDescriptionEn,
                    humidity = cached.humidity,
                    surfacePressureHpa = cached.surfacePressureHpa,
                    precipitationMm = cached.precipitationMm,
                    windDetails = windDetails,
                    hourlyForecasts = parsedHourly,
                    dailyForecasts = parsedDaily,
                    activeAlerts = parsedAlerts,
                    lastUpdatedTimestamp = cached.cachedTimestamp,
                    isOfflineCached = true
                )
                Result.success(cachedInfo)
            } else {
                // Fallback rich sample dataset if first run and fully offline
                val fallback = createFallbackWeather(location)
                Result.success(fallback)
            }
        }
    }

    suspend fun searchCities(query: String): List<LocationItem> = withContext(Dispatchers.IO) {
        if (query.trim().length < 2) return@withContext emptyList()
        try {
            val response = apiService.searchCities(query.trim())
            response.results?.map { dto ->
                LocationItem(
                    id = dto.id ?: System.currentTimeMillis(),
                    name = dto.name,
                    country = dto.country ?: "",
                    admin1 = dto.admin1,
                    latitude = dto.latitude,
                    longitude = dto.longitude,
                    isFavorite = false
                )
            } ?: emptyList()
        } catch (_: Exception) {
            // Local Turkish & world popular city search fallback
            getPopularCities().filter {
                it.name.contains(query, ignoreCase = true) || it.country.contains(query, ignoreCase = true)
            }
        }
    }

    suspend fun addSavedLocation(location: LocationItem): Long = withContext(Dispatchers.IO) {
        weatherDao.insertLocation(
            SavedLocationEntity(
                name = location.name,
                country = location.country,
                admin1 = location.admin1,
                latitude = location.latitude,
                longitude = location.longitude,
                isFavorite = true,
                isDefault = location.isCurrentGps
            )
        )
    }

    suspend fun removeSavedLocation(locationId: Long) = withContext(Dispatchers.IO) {
        weatherDao.deleteLocationById(locationId)
    }

    suspend fun markAlertRead(alertId: String) = withContext(Dispatchers.IO) {
        weatherDao.markAlertAsRead(alertId)
    }

    suspend fun clearAlerts() = withContext(Dispatchers.IO) {
        weatherDao.clearAllAlerts()
    }

    suspend fun performCloudSync(): Boolean = withContext(Dispatchers.IO) {
        // Simulated Cloud Storage sync handshake
        kotlinx.coroutines.delay(1200) // Realistic cloud round-trip
        true
    }

    fun getPopularCities(): List<LocationItem> {
        return listOf(
            LocationItem(101, "İstanbul", "Türkiye", "Marmara", 41.0082, 28.9784, true),
            LocationItem(102, "Ankara", "Türkiye", "İç Anadolu", 39.9334, 32.8597, true),
            LocationItem(103, "İzmir", "Türkiye", "Ege", 38.4237, 27.1428, true),
            LocationItem(104, "Antalya", "Türkiye", "Akdeniz", 36.8969, 30.7133, false),
            LocationItem(105, "Bursa", "Türkiye", "Marmara", 40.1885, 29.0610, false),
            LocationItem(106, "Trabzon", "Türkiye", "Karadeniz", 41.0027, 39.7168, false),
            LocationItem(107, "London", "United Kingdom", "England", 51.5074, -0.1278, false),
            LocationItem(108, "New York", "United States", "New York", 40.7128, -74.0060, false),
            LocationItem(109, "Tokyo", "Japan", "Kanto", 35.6762, 139.6503, false),
            LocationItem(110, "Berlin", "Germany", "Berlin", 52.5200, 13.4050, false),
            LocationItem(111, "Paris", "France", "Île-de-France", 48.8566, 2.3522, false)
        )
    }

    fun createFallbackWeather(location: LocationItem): WeatherInfo {
        val windDetails = WindDetails(
            speedKmh = 22.0,
            directionDegrees = 45,
            gustKmh = 34.0,
            beaufortScale = BeaufortScale.MODERATE_BREEZE
        )

        val hourly = (0..23).map { i ->
            HourlyForecast(
                timeLabel = String.format("%02d:00", i),
                temperature = 22.0 + Math.sin(i.toDouble() / 4) * 5,
                weatherCode = if (i in 12..17) 0 else 1,
                precipitationProbability = if (i in 15..19) 15 else 0,
                windSpeedKmh = 18.0 + (i % 6),
                windDirectionDegrees = 45 + (i * 5) % 360
            )
        }

        val days = listOf("Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar")
        val daysEn = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
        val daily = days.mapIndexed { idx, day ->
            DailyForecast(
                dateLabelTr = if (idx == 0) "Bugün" else if (idx == 1) "Yarın" else day,
                dateLabelEn = if (idx == 0) "Today" else if (idx == 1) "Tomorrow" else daysEn[idx],
                weatherCode = if (idx % 3 == 0) 0 else if (idx % 3 == 1) 2 else 61,
                maxTemp = 24.0 + (idx % 4),
                minTemp = 16.0 + (idx % 3),
                precipitationProbability = (idx * 12) % 60,
                precipitationSumMm = if (idx % 3 == 2) 4.2 else 0.0,
                maxWindSpeedKmh = 25.0 + idx * 2,
                maxGustKmh = 38.0 + idx * 3,
                uvIndex = 6.0,
                sunrise = "06:12",
                sunset = "19:48"
            )
        }

        return WeatherInfo(
            cityName = location.name,
            country = location.country,
            latitude = location.latitude,
            longitude = location.longitude,
            currentTemp = 23.0,
            feelsLikeTemp = 24.0,
            weatherCode = 1,
            weatherDescriptionTr = "Az Bulutlu ve Tatlı Esinti",
            weatherDescriptionEn = "Partly Cloudy with Fresh Breeze",
            humidity = 58,
            surfacePressureHpa = 1014.0,
            precipitationMm = 0.0,
            windDetails = windDetails,
            hourlyForecasts = hourly,
            dailyForecasts = daily,
            activeAlerts = emptyList(),
            lastUpdatedTimestamp = System.currentTimeMillis(),
            isOfflineCached = true
        )
    }
}
