package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WeatherDao {
    // Cached weather
    @Query("SELECT * FROM weather_cache WHERE locationKey = :locationKey LIMIT 1")
    suspend fun getCachedWeather(locationKey: String): WeatherCacheEntity?

    @Query("SELECT * FROM weather_cache")
    fun getAllCachedWeather(): Flow<List<WeatherCacheEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCachedWeather(weather: WeatherCacheEntity)

    @Query("DELETE FROM weather_cache WHERE locationKey = :locationKey")
    suspend fun deleteCachedWeather(locationKey: String)

    // Saved locations
    @Query("SELECT * FROM saved_locations ORDER BY isDefault DESC, addedTimestamp DESC")
    fun getSavedLocations(): Flow<List<SavedLocationEntity>>

    @Query("SELECT * FROM saved_locations WHERE id = :id LIMIT 1")
    suspend fun getLocationById(id: Long): SavedLocationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocation(location: SavedLocationEntity): Long

    @Update
    suspend fun updateLocation(location: SavedLocationEntity)

    @Query("DELETE FROM saved_locations WHERE id = :id")
    suspend fun deleteLocationById(id: Long)

    @Query("UPDATE saved_locations SET isDefault = (CASE WHEN id = :selectedId THEN 1 ELSE 0 END)")
    suspend fun setDefaultLocation(selectedId: Long)

    // Severe alerts history
    @Query("SELECT * FROM severe_alerts ORDER BY timestamp DESC")
    fun getAllAlerts(): Flow<List<SevereAlertEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlert(alert: SevereAlertEntity)

    @Query("UPDATE severe_alerts SET isRead = 1 WHERE alertId = :alertId")
    suspend fun markAlertAsRead(alertId: String)

    @Query("DELETE FROM severe_alerts")
    suspend fun clearAllAlerts()
}
