package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weather_cache")
data class WeatherCacheEntity(
    @PrimaryKey val locationKey: String, // "lat_lon" or "cityName"
    val cityName: String,
    val country: String,
    val latitude: Double,
    val longitude: Double,
    val currentTemp: Double,
    val feelsLikeTemp: Double,
    val weatherCode: Int,
    val weatherDescriptionTr: String,
    val weatherDescriptionEn: String,
    val humidity: Int,
    val surfacePressureHpa: Double,
    val precipitationMm: Double,
    val windSpeedKmh: Double,
    val windDirectionDegrees: Int,
    val windGustKmh: Double,
    val hourlyJson: String, // serialized hourly forecast
    val dailyJson: String,  // serialized daily forecast
    val alertsJson: String, // serialized active alerts
    val cachedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_locations")
data class SavedLocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val country: String,
    val admin1: String? = null,
    val latitude: Double,
    val longitude: Double,
    val isFavorite: Boolean = true,
    val isDefault: Boolean = false,
    val addedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "severe_alerts")
data class SevereAlertEntity(
    @PrimaryKey val alertId: String,
    val locationName: String,
    val titleTr: String,
    val titleEn: String,
    val messageTr: String,
    val messageEn: String,
    val severityLevel: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
