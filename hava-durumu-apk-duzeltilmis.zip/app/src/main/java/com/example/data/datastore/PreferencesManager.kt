package com.example.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AppLanguage
import com.example.data.model.AppThemeMode
import com.example.data.model.TemperatureUnit
import com.example.data.model.WidgetConfig
import com.example.data.model.WindUnit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_weather_settings")

class PreferencesManager(private val context: Context) {

    companion object {
        val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        val KEY_LANGUAGE = stringPreferencesKey("app_language")
        val KEY_TEMP_UNIT = stringPreferencesKey("temp_unit")
        val KEY_WIND_UNIT = stringPreferencesKey("wind_unit")

        val KEY_NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val KEY_WIND_ALERT_THRESHOLD = doublePreferencesKey("wind_alert_threshold") // in km/h
        val KEY_TEMP_HEAT_ALERT = doublePreferencesKey("temp_heat_alert") // in C
        val KEY_TEMP_FROST_ALERT = doublePreferencesKey("temp_frost_alert") // in C
        val KEY_STORM_ALERT_ENABLED = booleanPreferencesKey("storm_alert_enabled")

        val KEY_CLOUD_SYNC_ENABLED = booleanPreferencesKey("cloud_sync_enabled")
        val KEY_LAST_CLOUD_SYNC = longPreferencesKey("last_cloud_sync")

        val KEY_WIDGET_STYLE = stringPreferencesKey("widget_style")
        val KEY_WIDGET_SHOW_WIND = booleanPreferencesKey("widget_show_wind")
        val KEY_WIDGET_SHOW_HOURLY = booleanPreferencesKey("widget_show_hourly")
        val KEY_WIDGET_SHOW_ALERTS = booleanPreferencesKey("widget_show_alerts")
        val KEY_WIDGET_SHOW_UV = booleanPreferencesKey("widget_show_uv")
        val KEY_WIDGET_GLASS = booleanPreferencesKey("widget_glass")
    }

    val themeModeFlow: Flow<AppThemeMode> = context.dataStore.data.map { preferences ->
        val code = preferences[KEY_THEME_MODE] ?: AppThemeMode.SYSTEM.code
        AppThemeMode.entries.find { it.code == code } ?: AppThemeMode.SYSTEM
    }

    val languageFlow: Flow<AppLanguage> = context.dataStore.data.map { preferences ->
        val code = preferences[KEY_LANGUAGE] ?: AppLanguage.TURKISH.code
        AppLanguage.entries.find { it.code == code } ?: AppLanguage.TURKISH
    }

    val tempUnitFlow: Flow<TemperatureUnit> = context.dataStore.data.map { preferences ->
        val name = preferences[KEY_TEMP_UNIT] ?: TemperatureUnit.CELSIUS.name
        try {
            TemperatureUnit.valueOf(name)
        } catch (_: Exception) {
            TemperatureUnit.CELSIUS
        }
    }

    val windUnitFlow: Flow<WindUnit> = context.dataStore.data.map { preferences ->
        val name = preferences[KEY_WIND_UNIT] ?: WindUnit.KMH.name
        try {
            WindUnit.valueOf(name)
        } catch (_: Exception) {
            WindUnit.KMH
        }
    }

    val notificationsEnabledFlow: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_NOTIFICATIONS_ENABLED] ?: true
    }

    val windAlertThresholdFlow: Flow<Double> = context.dataStore.data.map {
        it[KEY_WIND_ALERT_THRESHOLD] ?: 45.0 // Default 45 km/h alert trigger
    }

    val cloudSyncEnabledFlow: Flow<Boolean> = context.dataStore.data.map {
        it[KEY_CLOUD_SYNC_ENABLED] ?: true
    }

    val lastCloudSyncFlow: Flow<Long> = context.dataStore.data.map {
        it[KEY_LAST_CLOUD_SYNC] ?: System.currentTimeMillis()
    }

    val widgetConfigFlow: Flow<WidgetConfig> = context.dataStore.data.map { pref ->
        WidgetConfig(
            widgetStyle = pref[KEY_WIDGET_STYLE] ?: "MODERN_CARD",
            showWindCompass = pref[KEY_WIDGET_SHOW_WIND] ?: true,
            showHourlyForecast = pref[KEY_WIDGET_SHOW_HOURLY] ?: true,
            showSevereAlerts = pref[KEY_WIDGET_SHOW_ALERTS] ?: true,
            showHumidityAndUV = pref[KEY_WIDGET_SHOW_UV] ?: true,
            transparentGlassBackground = pref[KEY_WIDGET_GLASS] ?: true
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode.code }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { it[KEY_LANGUAGE] = language.code }
    }

    suspend fun setTempUnit(unit: TemperatureUnit) {
        context.dataStore.edit { it[KEY_TEMP_UNIT] = unit.name }
    }

    suspend fun setWindUnit(unit: WindUnit) {
        context.dataStore.edit { it[KEY_WIND_UNIT] = unit.name }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun setWindAlertThreshold(thresholdKmh: Double) {
        context.dataStore.edit { it[KEY_WIND_ALERT_THRESHOLD] = thresholdKmh }
    }

    suspend fun setCloudSyncEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_CLOUD_SYNC_ENABLED] = enabled }
    }

    suspend fun updateLastCloudSync(timestamp: Long) {
        context.dataStore.edit { it[KEY_LAST_CLOUD_SYNC] = timestamp }
    }

    suspend fun updateWidgetConfig(config: WidgetConfig) {
        context.dataStore.edit { pref ->
            pref[KEY_WIDGET_STYLE] = config.widgetStyle
            pref[KEY_WIDGET_SHOW_WIND] = config.showWindCompass
            pref[KEY_WIDGET_SHOW_HOURLY] = config.showHourlyForecast
            pref[KEY_WIDGET_SHOW_ALERTS] = config.showSevereAlerts
            pref[KEY_WIDGET_SHOW_UV] = config.showHumidityAndUV
            pref[KEY_WIDGET_GLASS] = config.transparentGlassBackground
        }
    }
}
