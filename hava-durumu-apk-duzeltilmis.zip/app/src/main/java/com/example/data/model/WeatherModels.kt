package com.example.data.model

enum class AppLanguage(val code: String, val displayName: String) {
    TURKISH("tr", "Türkçe"),
    ENGLISH("en", "English")
}

enum class AppThemeMode(val code: String) {
    SYSTEM("system"),
    LIGHT("light"),
    DARK("dark"),
    AMOLED("amoled")
}

enum class TemperatureUnit(val symbol: String, val label: String) {
    CELSIUS("°C", "Santigrat (°C)"),
    FAHRENHEIT("°F", "Fahrenhayt (°F)");

    fun format(tempCelsius: Double): String {
        return when (this) {
            CELSIUS -> "${Math.round(tempCelsius)}°C"
            FAHRENHEIT -> "${Math.round((tempCelsius * 9 / 5) + 32)}°F"
        }
    }

    fun convertValue(tempCelsius: Double): Double {
        return when (this) {
            CELSIUS -> tempCelsius
            FAHRENHEIT -> (tempCelsius * 9 / 5) + 32
        }
    }
}

enum class WindUnit(val symbolTr: String, val symbolEn: String, val factorFromKmh: Double) {
    KMH("km/s", "km/h", 1.0),
    MS("m/sn", "m/s", 0.277778),
    MPH("mil/s", "mph", 0.621371),
    KNOTS("knot", "knots", 0.539957);

    fun format(speedKmh: Double, isTurkish: Boolean): String {
        val converted = speedKmh * factorFromKmh
        val symbol = if (isTurkish) symbolTr else symbolEn
        return "${String.format("%.1f", converted)} $symbol"
    }
}

enum class BeaufortScale(
    val level: Int,
    val nameTr: String,
    val nameEn: String,
    val minKmh: Double,
    val maxKmh: Double,
    val descriptionTr: String,
    val descriptionEn: String
) {
    CALM(0, "Sakin", "Calm", 0.0, 1.9, "Duman dik yükselir, yapraklar kımıldamaz.", "Smoke rises vertically, leaves still."),
    LIGHT_AIR(1, "Çok Hafif Esinti", "Light Air", 2.0, 5.9, "Rüzgarın yönü dumanla anlaşılır.", "Wind direction shown by smoke drift."),
    LIGHT_BREEZE(2, "Hafif Meltem", "Light Breeze", 6.0, 11.9, "Rüzgar yüzde hissedilir, yapraklar fısıldar.", "Wind felt on face; leaves rustle."),
    GENTLE_BREEZE(3, "Tatlı Meltem", "Gentle Breeze", 12.0, 19.9, "Yapraklar ve ince dallar sürekli sallanır.", "Leaves and small twigs in constant motion."),
    MODERATE_BREEZE(4, "Orta Rüzgar", "Moderate Breeze", 20.0, 28.9, "Toz ve kağıtlar kalkar, küçük dallar oynar.", "Raises dust and loose paper; small branches move."),
    FRESH_BREEZE(5, "Ferah Rüzgar", "Fresh Breeze", 29.0, 38.9, "Küçük yapraklı ağaçlar sallanmaya başlar.", "Small trees in leaf begin to sway."),
    STRONG_BREEZE(6, "Kuvvetli Rüzgar", "Strong Breeze", 39.0, 49.9, "Büyük dallar sallanır, şemsiye zor tutulur.", "Large branches in motion; umbrellas used with difficulty."),
    HIGH_WIND(7, "Sert Rüzgar", "High Wind / Moderate Gale", 50.0, 61.9, "Bütün ağaçlar sallanır, rüzgara karşı yürümek güçleşir.", "Whole trees in motion; resistance felt walking against wind."),
    GALE(8, "Fırtına", "Gale", 62.0, 74.9, "Ağaç dalları kırılır, yürümek oldukça zordur.", "Twigs break off trees; generally impedes progress."),
    STRONG_GALE(9, "Kuvvetli Fırtına", "Strong Gale", 75.0, 88.9, "Yapılarda ufak hasarlar oluşur (baca, kiremitler uçar).", "Slight structural damage occurs; chimney pots removed."),
    STORM(10, "Tam Fırtına", "Storm", 89.0, 102.9, "Ağaçlar kökünden sökülür, ciddi hasarlar meydana gelir.", "Trees uprooted; considerable structural damage occurs."),
    VIOLENT_STORM(11, "Çok Şiddetli Fırtına", "Violent Storm", 103.0, 117.9, "Geniş çaplı yıkım ve ağır hasar.", "Widespread damage."),
    HURRICANE(12, "Kasırga", "Hurricane", 118.0, 999.0, "Olağanüstü yıkıcı afet etkisi.", "Devastation occurs.");

    companion object {
        fun fromSpeedKmh(speedKmh: Double): BeaufortScale {
            return entries.find { speedKmh >= it.minKmh && speedKmh <= it.maxKmh } ?: HURRICANE
        }
    }
}

enum class AlertSeverity(val level: String, val colorHex: Long) {
    INFO("Bilgi / Info", 0xFF0284C7),
    ADVISORY("Sarı Uyarı / Moderate Advisory", 0xFFEAB308),
    WARNING("Turuncu Uyarı / Severe Warning", 0xFFF97316),
    DANGER("Kırmızı Alarm / Extreme Danger", 0xFFEF4444)
}

data class WindDetails(
    val speedKmh: Double,
    val directionDegrees: Int,
    val gustKmh: Double,
    val beaufortScale: BeaufortScale
) {
    val cardinalDirection: String
        get() = when (((directionDegrees + 22.5) % 360 / 45).toInt()) {
            0 -> "K / N"
            1 -> "KD / NE"
            2 -> "D / E"
            3 -> "GD / SE"
            4 -> "G / S"
            5 -> "GB / SW"
            6 -> "B / W"
            7 -> "KB / NW"
            else -> "K / N"
        }

    fun cardinalDirectionLocalized(isTurkish: Boolean): String {
        return when (((directionDegrees + 22.5) % 360 / 45).toInt()) {
            0 -> if (isTurkish) "Kuzey (K)" else "North (N)"
            1 -> if (isTurkish) "Kuzeydoğu (KD)" else "Northeast (NE)"
            2 -> if (isTurkish) "Doğu (D)" else "East (E)"
            3 -> if (isTurkish) "Güneydoğu (GD)" else "Southeast (SE)"
            4 -> if (isTurkish) "Güney (G)" else "South (S)"
            5 -> if (isTurkish) "Güneybatı (GB)" else "Southwest (SW)"
            6 -> if (isTurkish) "Batı (B)" else "West (W)"
            7 -> if (isTurkish) "Kuzeybatı (KB)" else "Northwest (NW)"
            else -> if (isTurkish) "Kuzey (K)" else "North (N)"
        }
    }
}

data class WeatherInfo(
    val cityName: String,
    val country: String,
    val latitude: Double,
    val longitude: Double,
    val currentTemp: Double,
    val feelsLikeTemp: Double,
    val weatherCode: Int,
    val weatherDescriptionTr: String,
    val weatherDescriptionEn: String,
    val humidity: Int,
    val surfacePressureHpa: Double,
    val precipitationMm: Double,
    val windDetails: WindDetails,
    val hourlyForecasts: List<HourlyForecast>,
    val dailyForecasts: List<DailyForecast>,
    val activeAlerts: List<SevereAlert>,
    val lastUpdatedTimestamp: Long = System.currentTimeMillis(),
    val isOfflineCached: Boolean = false
)

data class HourlyForecast(
    val timeLabel: String,
    val temperature: Double,
    val weatherCode: Int,
    val precipitationProbability: Int,
    val windSpeedKmh: Double,
    val windDirectionDegrees: Int
)

data class DailyForecast(
    val dateLabelTr: String,
    val dateLabelEn: String,
    val weatherCode: Int,
    val maxTemp: Double,
    val minTemp: Double,
    val precipitationProbability: Int,
    val precipitationSumMm: Double,
    val maxWindSpeedKmh: Double,
    val maxGustKmh: Double,
    val uvIndex: Double,
    val sunrise: String,
    val sunset: String
)

data class SevereAlert(
    val id: String,
    val titleTr: String,
    val titleEn: String,
    val messageTr: String,
    val messageEn: String,
    val severity: AlertSeverity,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val sourceLocation: String
)

data class LocationItem(
    val id: Long = 0,
    val name: String,
    val country: String,
    val admin1: String? = null,
    val latitude: Double,
    val longitude: Double,
    val isFavorite: Boolean = false,
    val isCurrentGps: Boolean = false
)

data class WidgetConfig(
    val widgetStyle: String = "MODERN_CARD", // MODERN_CARD, COMPACT_BAR, WIND_RADAR, 5_DAY_EXPANDED
    val showWindCompass: Boolean = true,
    val showHourlyForecast: Boolean = true,
    val showSevereAlerts: Boolean = true,
    val showHumidityAndUV: Boolean = true,
    val transparentGlassBackground: Boolean = true
)

data class CloudSyncStatus(
    val isSyncEnabled: Boolean = true,
    val lastSyncTimestamp: Long = System.currentTimeMillis(),
    val totalSyncedLocations: Int = 1,
    val isSyncing: Boolean = false
)

data class SmartWeatherAdvice(
    val titleTr: String,
    val titleEn: String,
    val summaryTr: String,
    val summaryEn: String,
    val clothingAdviceTr: String,
    val clothingAdviceEn: String,
    val windAnalysisTr: String,
    val windAnalysisEn: String,
    val activityAdviceTr: String,
    val activityAdviceEn: String,
    val recommendedGearTr: List<String>,
    val recommendedGearEn: List<String>,
    val isAlertUrgent: Boolean,
    val badgeCategory: String // "FREEZING", "COLD", "MILD", "WARM", "HOT", "STORM", "RAIN"
)
