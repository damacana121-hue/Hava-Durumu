package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.AlertSeverity
import com.example.data.model.SevereAlert
import com.example.data.model.SmartWeatherAdvice

class WeatherNotificationManager(private val context: Context) {

    companion object {
        const val CHANNEL_SEVERE_ALERTS = "severe_weather_alerts_channel"
        const val CHANNEL_DAILY_FORECAST = "daily_weather_forecast_channel"
        private const val NOTIFICATION_ID_BASE = 1001
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Severe weather warning channel
            val severeChannel = NotificationChannel(
                CHANNEL_SEVERE_ALERTS,
                "Olumsuz Hava Koşulları / Severe Weather Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Fırtına, şiddetli rüzgar ve ekstrem hava durumu uyarıları / Severe wind, storm and weather alerts"
                enableVibration(true)
            }

            // Daily summary channel
            val forecastChannel = NotificationChannel(
                CHANNEL_DAILY_FORECAST,
                "Günlük Hava Tahminleri / Daily Forecast Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Günlük hava durumu ve sıcaklık bildirimleri / Daily weather summaries"
            }

            notificationManager.createNotificationChannel(severeChannel)
            notificationManager.createNotificationChannel(forecastChannel)
        }
    }

    fun sendSevereAlertNotification(alert: SevereAlert, isTurkish: Boolean): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isTurkish) alert.titleTr else alert.titleEn
        val message = if (isTurkish) alert.messageTr else alert.messageEn

        val priority = when (alert.severity) {
            AlertSeverity.DANGER -> NotificationCompat.PRIORITY_MAX
            AlertSeverity.WARNING -> NotificationCompat.PRIORITY_HIGH
            AlertSeverity.ADVISORY -> NotificationCompat.PRIORITY_DEFAULT
            AlertSeverity.INFO -> NotificationCompat.PRIORITY_LOW
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_SEVERE_ALERTS)
            .setSmallIcon(R.drawable.ic_weather_logo)
            .setContentTitle("⚠️ $title")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message).setSummaryText(alert.sourceLocation))
            .setPriority(priority)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        try {
            val notificationId = (alert.id.hashCode() and 0x7FFFFFFF) % 10000 + NOTIFICATION_ID_BASE
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
            return true
        } catch (_: SecurityException) {
            return false
        } catch (_: Exception) {
            return false
        }
    }

    fun sendDailyForecastNotification(cityName: String, tempFormatted: String, condition: String, windFormatted: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            1,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val text = "$cityName: $tempFormatted, $condition. Rüzgar / Wind: $windFormatted"

        val builder = NotificationCompat.Builder(context, CHANNEL_DAILY_FORECAST)
            .setSmallIcon(R.drawable.ic_weather_logo)
            .setContentTitle("🌤️ $cityName Hava Durumu")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        try {
            NotificationManagerCompat.from(context).notify(2001, builder.build())
        } catch (_: Exception) {
        }
    }

    fun sendSmartAdviceNotification(advice: SmartWeatherAdvice, cityName: String, isTurkish: Boolean): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return false
            }
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            2,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isTurkish) advice.titleTr else advice.titleEn
        val clothing = if (isTurkish) advice.clothingAdviceTr else advice.clothingAdviceEn
        val wind = if (isTurkish) advice.windAnalysisTr else advice.windAnalysisEn
        val fullText = "$clothing\n\n$wind"

        val builder = NotificationCompat.Builder(context, CHANNEL_SEVERE_ALERTS)
            .setSmallIcon(R.drawable.ic_weather_logo)
            .setContentTitle("💡 $cityName: $title")
            .setContentText(if (isTurkish) advice.summaryTr else advice.summaryEn)
            .setStyle(NotificationCompat.BigTextStyle().bigText(fullText).setSummaryText("$cityName • Akıllı Tavsiye"))
            .setPriority(if (advice.isAlertUrgent) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        try {
            NotificationManagerCompat.from(context).notify(3001, builder.build())
            return true
        } catch (_: Exception) {
            return false
        }
    }
}
