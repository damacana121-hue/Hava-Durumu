package com.example.ui.localization

import com.example.data.model.AppLanguage

object AppStrings {
    fun get(key: String, lang: AppLanguage): String {
        val isTr = lang == AppLanguage.TURKISH
        return when (key) {
            // App Title & Tabs
            "app_title" -> if (isTr) "Hava Durumu" else "Weather Forecast"
            "tab_today" -> if (isTr) "Bugün" else "Today"
            "tab_wind" -> if (isTr) "Rüzgar & Fırtına" else "Wind & Storm"
            "tab_locations" -> if (isTr) "Konumlar" else "Locations"
            "tab_alerts" -> if (isTr) "Uyarılar" else "Alerts"
            "tab_widgets" -> if (isTr) "Widget'lar" else "Widgets"
            "tab_settings" -> if (isTr) "Ayarlar" else "Settings"

            // Weather Metrics & Labels
            "feels_like" -> if (isTr) "Hissedilen" else "Feels like"
            "wind_speed" -> if (isTr) "Rüzgar Hızı" else "Wind Speed"
            "wind_direction" -> if (isTr) "Rüzgar Yönü" else "Wind Direction"
            "wind_gusts" -> if (isTr) "Rüzgar Hamlesi" else "Wind Gusts"
            "beaufort_scale" -> if (isTr) "Beaufort Ölçeği" else "Beaufort Scale"
            "humidity" -> if (isTr) "Nem Oranı" else "Humidity"
            "pressure" -> if (isTr) "Hava Basıncı" else "Air Pressure"
            "uv_index" -> if (isTr) "UV İndeksi" else "UV Index"
            "precipitation" -> if (isTr) "Yağış İhtimali" else "Precipitation"
            "rain_amount" -> if (isTr) "Yağış Miktarı" else "Precipitation Volume"
            "sunrise" -> if (isTr) "Gün Doğumu" else "Sunrise"
            "sunset" -> if (isTr) "Gün Batımı" else "Sunset"

            // Forecasts
            "hourly_forecast" -> if (isTr) "24 Saatlik Sıcaklık & Rüzgar" else "24-Hour Temp & Wind"
            "daily_forecast" -> if (isTr) "7 Günlük Tahmin" else "7-Day Forecast"
            "today" -> if (isTr) "Bugün" else "Today"
            "tomorrow" -> if (isTr) "Yarın" else "Tomorrow"
            "low_high" -> if (isTr) "En Düşük / En Yüksek" else "Min / Max"

            // Wind Analysis Card
            "wind_analysis_title" -> if (isTr) "Canlı Rüzgar Pusulası & Analiz" else "Live Wind Compass & Analysis"
            "wind_status_safe" -> if (isTr) "Rüzgar durumu normal ve güvenli" else "Wind conditions normal and safe"
            "wind_status_gale" -> if (isTr) "Dikkat: Şiddetli rüzgar ve fırtına hamleleri!" else "Caution: High wind & storm gusts!"
            "wind_calm" -> if (isTr) "Sakin Hava" else "Calm"
            "wind_breeze" -> if (isTr) "Esinti / Meltem" else "Breeze"
            "wind_gale" -> if (isTr) "Fırtına" else "Gale"
            "wind_compass_tap" -> if (isTr) "Canlı pusula rüzgar akışını gösterir" else "Live compass indicates wind bearing"

            // Severe Weather Warnings & Notifications
            "severe_alerts_title" -> if (isTr) "Olumsuz Hava Koşulları Uyarıları" else "Severe Weather Warnings"
            "severe_alerts_badge" -> if (isTr) "Kritik Hava Uyarısı" else "Severe Alert Active"
            "no_active_alerts" -> if (isTr) "Şu anda olumsuz hava uyarısı bulunmamaktadır." else "No active severe weather warnings."
            "test_notification_btn" -> if (isTr) "Örnek Uyarı Bildirimi Gönder" else "Send Test Alert Notification"
            "notification_permission_hint" -> if (isTr) "Konum tabanlı fırtına ve ani hava değişimlerinden haberdar olmak için bildirimleri açın." else "Enable notifications for location-based severe weather alerts."
            "notification_threshold_title" -> if (isTr) "Uyarı Eşik Değerleri" else "Alert Thresholds"
            "wind_threshold_slider" -> if (isTr) "Rüzgar Uyarı Eşiği" else "Wind Alert Threshold"
            "alert_sensitivity" -> if (isTr) "Fırtına & Şiddetli Yağış Uyarıları" else "Storm & Heavy Rain Alerts"
            "location_alerts_toggle" -> if (isTr) "Konum Tabanlı Uyarı Bildirimleri" else "Location-Based Alert Notifications"

            // Offline & Cloud Sync
            "offline_badge" -> if (isTr) "Çevrimdışı Önbellek" else "Offline Cached"
            "live_badge" -> if (isTr) "Canlı Veri" else "Live Data"
            "last_updated" -> if (isTr) "Son Güncelleme" else "Last Updated"
            "offline_mode_info" -> if (isTr) "İnternet bağlantısı olmasa bile tüm hava durumu verileriniz ve kayıtlı konumlarınız cihazda saklanır." else "All weather forecasts and saved locations are stored locally for full offline access."
            "cloud_sync_title" -> if (isTr) "Bulut Depolama & Senkronizasyon" else "Cloud Storage & Sync"
            "cloud_sync_desc" -> if (isTr) "Kayıtlı konumlarınızı ve uyarı geçmişinizi buluta yedekleyin veya geri yükleyin." else "Backup or restore your saved cities and alert logs across devices."
            "cloud_sync_now_btn" -> if (isTr) "Buluta Şimdi Senkronize Et" else "Sync to Cloud Now"
            "cloud_restore_btn" -> if (isTr) "Buluttan Geri Yükle" else "Restore from Cloud"
            "cloud_auto_sync" -> if (isTr) "Otomatik Bulut Eşitleme" else "Automatic Cloud Sync"
            "cloud_synced_success" -> if (isTr) "Bulut senkronizasyonu başarıyla tamamlandı!" else "Cloud synchronization completed successfully!"

            // Widgets Customization
            "widgets_title" -> if (isTr) "Özelleştirilebilir Widget'lar" else "Customizable Widgets"
            "widgets_subtitle" -> if (isTr) "Ana ekranınız ve özet kartlarınız için özel widget tasarımı oluşturun." else "Customize widgets and overview cards for your home dashboard."
            "widget_style" -> if (isTr) "Widget Teması & Stili" else "Widget Theme & Style"
            "widget_style_modern" -> if (isTr) "Modern Kart" else "Modern Card"
            "widget_style_glass" -> if (isTr) "Cam Efekti (Glassmorphism)" else "Glassmorphism"
            "widget_style_wind" -> if (isTr) "Rüzgar & Pusula Odaklı" else "Wind & Compass Focus"
            "widget_style_extended" -> if (isTr) "5 Günlük Genişletilmiş" else "5-Day Extended"
            "widget_show_wind" -> if (isTr) "Rüzgar Pusulasını Göster" else "Show Wind Compass"
            "widget_show_hourly" -> if (isTr) "Saatlik Grafiği Göster" else "Show Hourly Strip"
            "widget_show_alerts" -> if (isTr) "Kritik Uyarıları Dahil Et" else "Include Severe Alerts"
            "widget_preview_title" -> if (isTr) "Canlı Widget Önizlemesi" else "Live Widget Preview"
            "widget_add_to_home" -> if (isTr) "Widget'ı Uygula & Kaydet" else "Apply & Save Widget"
            "widget_saved_toast" -> if (isTr) "Widget tercihleri başarıyla güncellendi." else "Widget preferences updated successfully."

            // Locations Search
            "search_city_placeholder" -> if (isTr) "Şehir veya konum ara (örn: İstanbul, İzmir, London)..." else "Search city or location (e.g. Istanbul, London)..."
            "current_location_gps" -> if (isTr) "Mevcut Konumum (GPS)" else "Current Location (GPS)"
            "saved_locations_title" -> if (isTr) "Kayıtlı Konumlar" else "Saved Locations"
            "add_to_favorites" -> if (isTr) "Favorilere Ekle" else "Add to Favorites"
            "remove_from_favorites" -> if (isTr) "Favorilerden Çıkar" else "Remove"
            "popular_cities" -> if (isTr) "Popüler Şehirler" else "Popular Cities"

            // Settings & Preferences
            "settings_title" -> if (isTr) "Uygulama Ayarları" else "Application Settings"
            "appearance_group" -> if (isTr) "Görünüm ve Tema" else "Appearance & Theme"
            "theme_mode" -> if (isTr) "Tema Seçimi" else "Theme Mode"
            "theme_system" -> if (isTr) "Sistem Varsayılanı" else "System Default"
            "theme_light" -> if (isTr) "Açık Mod" else "Light Mode"
            "theme_dark" -> if (isTr) "Karanlık Mod" else "Dark Mode"
            "theme_amoled" -> if (isTr) "AMOLED Siyah" else "AMOLED Black"
            "language_group" -> if (isTr) "Dil Tercihi" else "Language"
            "units_group" -> if (isTr) "Birimler" else "Units"
            "temp_unit" -> if (isTr) "Sıcaklık Birimi" else "Temperature Unit"
            "wind_unit" -> if (isTr) "Rüzgar Hız Birimi" else "Wind Unit"
            "accessibility_group" -> if (isTr) "Erişilebilirlik & Sesli Geri Bildirim" else "Accessibility & Voice Assistance"
            "accessibility_desc" -> if (isTr) "Yüksek kontrast, TalkBack ekran okuyucu uyumluluğu ve 48dp dokunma alanları etkindir." else "High contrast, TalkBack screen reader support and 48dp touch targets active."

            // Common Actions
            "refresh" -> if (isTr) "Yenile" else "Refresh"
            "refreshing" -> if (isTr) "Güncelleniyor..." else "Updating..."
            "retry" -> if (isTr) "Yeniden Dene" else "Retry"
            "close" -> if (isTr) "Kapat" else "Close"
            "save" -> if (isTr) "Kaydet" else "Save"
            "cancel" -> if (isTr) "İptal" else "Cancel"
            "error_network" -> if (isTr) "İnternet bağlantısı kurulamadı. Çevrimdışı veriler gösteriliyor." else "Network unavailable. Showing offline cached data."
            else -> key
        }
    }
}
