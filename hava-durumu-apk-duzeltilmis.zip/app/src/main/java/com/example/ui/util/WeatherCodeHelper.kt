package com.example.ui.util

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class WeatherConditionDisplay(
    val descriptionTr: String,
    val descriptionEn: String,
    val icon: ImageVector,
    val primaryColor: Color,
    val gradient: Brush
)

object WeatherCodeHelper {
    fun getDisplay(code: Int, isNight: Boolean = false): WeatherConditionDisplay {
        return when (code) {
            0 -> if (isNight) {
                WeatherConditionDisplay(
                    descriptionTr = "Açık ve Yıldızlı",
                    descriptionEn = "Clear Night",
                    icon = Icons.Default.NightsStay,
                    primaryColor = Color(0xFF6366F1),
                    gradient = Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF312E81)))
                )
            } else {
                WeatherConditionDisplay(
                    descriptionTr = "Güneşli ve Açık",
                    descriptionEn = "Sunny & Clear",
                    icon = Icons.Default.WbSunny,
                    primaryColor = Color(0xFFF59E0B),
                    gradient = Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF0284C7), Color(0xFFF59E0B)))
                )
            }
            1, 2 -> WeatherConditionDisplay(
                descriptionTr = "Az Bulutlu",
                descriptionEn = "Partly Cloudy",
                icon = Icons.Default.CloudQueue,
                primaryColor = Color(0xFF38BDF8),
                gradient = Brush.linearGradient(listOf(Color(0xFF0369A1), Color(0xFF0EA5E9), Color(0xFF7DD3FC)))
            )
            3 -> WeatherConditionDisplay(
                descriptionTr = "Kapalı Bulutlu",
                descriptionEn = "Overcast",
                icon = Icons.Default.Cloud,
                primaryColor = Color(0xFF94A3B8),
                gradient = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF334155), Color(0xFF64748B)))
            )
            45, 48 -> WeatherConditionDisplay(
                descriptionTr = "Sisli ve Puslu",
                descriptionEn = "Foggy & Misty",
                icon = Icons.Default.Air,
                primaryColor = Color(0xFF94A3B8),
                gradient = Brush.linearGradient(listOf(Color(0xFF334155), Color(0xFF475569), Color(0xFF64748B)))
            )
            51, 53, 55 -> WeatherConditionDisplay(
                descriptionTr = "Hafif Çisenti Yağış",
                descriptionEn = "Light Drizzle",
                icon = Icons.Default.Grain,
                primaryColor = Color(0xFF06B6D4),
                gradient = Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF164E63), Color(0xFF0891B2)))
            )
            61, 63, 65 -> WeatherConditionDisplay(
                descriptionTr = "Yağmurlu",
                descriptionEn = "Rainy",
                icon = Icons.Default.WaterDrop,
                primaryColor = Color(0xFF0284C7),
                gradient = Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF0369A1), Color(0xFF0284C7)))
            )
            71, 73, 75, 77 -> WeatherConditionDisplay(
                descriptionTr = "Kar Yağışlı",
                descriptionEn = "Snow Showers",
                icon = Icons.Default.Grain,
                primaryColor = Color(0xFFE0F2FE),
                gradient = Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF38BDF8), Color(0xFFE0F2FE)))
            )
            80, 81, 82 -> WeatherConditionDisplay(
                descriptionTr = "Kuvvetli Sağanak Yağış",
                descriptionEn = "Heavy Rain Showers",
                icon = Icons.Default.WaterDrop,
                primaryColor = Color(0xFF2563EB),
                gradient = Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF1E3A8A), Color(0xFF2563EB)))
            )
            95, 96, 99 -> WeatherConditionDisplay(
                descriptionTr = "Gök Gürültülü Fırtına",
                descriptionEn = "Thunderstorm & Storm",
                icon = Icons.Default.Thunderstorm,
                primaryColor = Color(0xFFF43F5E),
                gradient = Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF4C0519), Color(0xFF9F1239)))
            )
            else -> WeatherConditionDisplay(
                descriptionTr = "Değişken Hava",
                descriptionEn = "Variable",
                icon = Icons.Default.CloudQueue,
                primaryColor = Color(0xFF38BDF8),
                gradient = Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF0369A1), Color(0xFF38BDF8)))
            )
        }
    }
}
