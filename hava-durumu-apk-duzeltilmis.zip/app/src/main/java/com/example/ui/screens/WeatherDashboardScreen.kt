package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.SevereAlert
import com.example.data.model.TemperatureUnit
import com.example.data.model.WeatherInfo
import com.example.data.model.WindUnit
import com.example.ui.components.DailyForecastSection
import com.example.ui.components.HourlyForecastSection
import com.example.ui.components.MetricDetailGrid
import com.example.ui.components.SevereAlertBanner
import com.example.ui.components.SmartWeatherAdvisorCard
import com.example.ui.components.WindCompassCard
import com.example.ui.localization.AppStrings
import com.example.ui.util.WeatherCodeHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherDashboardScreen(
    weather: WeatherInfo,
    isRefreshing: Boolean,
    tempUnit: TemperatureUnit,
    windUnit: WindUnit,
    language: AppLanguage,
    onRefresh: () -> Unit,
    onSearchClick: () -> Unit,
    onAlertClick: (SevereAlert) -> Unit,
    modifier: Modifier = Modifier
) {
    val isTr = language == AppLanguage.TURKISH
    val condition = WeatherCodeHelper.getDisplay(weather.weatherCode)

    val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    val lastUpdateStr = timeFormat.format(Date(weather.lastUpdatedTimestamp))

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("weather_dashboard_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Weather Header Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hero_weather_card"),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(28.dp))
                ) {
                    // Hero image illustration background with vibrant sun cover
                    Image(
                        painter = painterResource(id = R.drawable.img_sun_hero_cover),
                        contentDescription = "Güneş Kapak Resmi",
                        modifier = Modifier.matchParentSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Atmospheric gradient overlay
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.35f),
                                        Color.Black.copy(alpha = 0.75f)
                                    )
                                )
                            )
                    )

                    // Hero Content
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Top bar: Location & Status badges
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f, fill = false),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "${weather.cityName}, ${weather.country}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                // Offline / Live badge
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (weather.isOfflineCached) Color(0xFFF59E0B).copy(alpha = 0.45f)
                                    else Color(0xFF10B981).copy(alpha = 0.45f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (weather.isOfflineCached) Icons.Default.CloudOff else Icons.Default.CloudDone,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Text(
                                            text = if (weather.isOfflineCached) AppStrings.get("offline_badge", language) else AppStrings.get("live_badge", language),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = onRefresh,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.25f))
                                        .testTag("dashboard_refresh_btn")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = AppStrings.get("refresh", language),
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        // Current Temperature & Condition Icon
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = tempUnit.format(weather.currentTemp),
                                    style = MaterialTheme.typography.displayMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    modifier = Modifier.semantics {
                                        contentDescription = "${weather.cityName} sıcaklık: ${tempUnit.format(weather.currentTemp)}"
                                    }
                                )
                                Text(
                                    text = if (isTr) weather.weatherDescriptionTr else weather.weatherDescriptionEn,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color.White.copy(alpha = 0.95f)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${AppStrings.get("feels_like", language)}: ${tempUnit.format(weather.feelsLikeTemp)} • ${AppStrings.get("last_updated", language)}: $lastUpdateStr",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(condition.primaryColor.copy(alpha = 0.45f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = condition.icon,
                                    contentDescription = condition.descriptionTr,
                                    tint = Color.White,
                                    modifier = Modifier.size(44.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Severe Alerts Banner if present
        if (weather.activeAlerts.isNotEmpty()) {
            item {
                SevereAlertBanner(
                    alerts = weather.activeAlerts,
                    language = language,
                    onAlertClick = onAlertClick
                )
            }
        }

        // Smart Weather & Wind Advisor Card (Akıllı Uyarı & Giyim Tavsiyesi)
        item {
            SmartWeatherAdvisorCard(
                weather = weather,
                language = language
            )
        }

        // Live Wind Compass & Detailed Wind Information Card
        item {
            WindCompassCard(
                windDetails = weather.windDetails,
                windUnit = windUnit,
                language = language
            )
        }

        // 24-Hour Temperature & Wind Forecast
        item {
            HourlyForecastSection(
                hourlyForecasts = weather.hourlyForecasts,
                tempUnit = tempUnit,
                windUnit = windUnit,
                language = language
            )
        }

        // 7-Day Daily Forecast Section
        item {
            DailyForecastSection(
                dailyForecasts = weather.dailyForecasts,
                tempUnit = tempUnit,
                windUnit = windUnit,
                language = language
            )
        }

        // Environmental Metrics Grid (Humidity, Pressure, UV, Sunrise/Sunset)
        item {
            MetricDetailGrid(
                weather = weather,
                tempUnit = tempUnit,
                language = language
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
