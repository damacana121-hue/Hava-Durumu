package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.TemperatureUnit
import com.example.data.model.WeatherInfo
import com.example.data.model.WidgetConfig
import com.example.data.model.WindUnit
import com.example.ui.localization.AppStrings
import com.example.ui.util.WeatherCodeHelper

@Composable
fun WidgetCustomizerCard(
    weather: WeatherInfo,
    config: WidgetConfig,
    tempUnit: TemperatureUnit,
    windUnit: WindUnit,
    language: AppLanguage,
    onConfigChange: (WidgetConfig) -> Unit,
    onSaveSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isTr = language == AppLanguage.TURKISH
    var savedSuccessState by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("widget_customizer_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        )
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Widgets,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = AppStrings.get("widgets_title", language),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = AppStrings.get("widgets_subtitle", language),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Live Preview of the Widget
            Text(
                text = AppStrings.get("widget_preview_title", language),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            // Dynamic Widget Preview Box
            WidgetPreviewRenderer(
                weather = weather,
                config = config,
                tempUnit = tempUnit,
                windUnit = windUnit,
                isTurkish = isTr
            )

            // Style selector in 2x2 grid
            Text(
                text = AppStrings.get("widget_style", language),
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "MODERN_CARD" to AppStrings.get("widget_style_modern", language),
                        "GLASS" to AppStrings.get("widget_style_glass", language)
                    ).forEach { (styleKey, styleLabel) ->
                        FilterChip(
                            selected = config.widgetStyle == styleKey,
                            onClick = { onConfigChange(config.copy(widgetStyle = styleKey)) },
                            label = { Text(styleLabel, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("widget_style_chip_$styleKey")
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "WIND_RADAR" to AppStrings.get("widget_style_wind", language),
                        "EXTENDED" to AppStrings.get("widget_style_extended", language)
                    ).forEach { (styleKey, styleLabel) ->
                        FilterChip(
                            selected = config.widgetStyle == styleKey,
                            onClick = { onConfigChange(config.copy(widgetStyle = styleKey)) },
                            label = { Text(styleLabel, style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("widget_style_chip_$styleKey")
                        )
                    }
                }
            }

            // Toggles for metrics
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                WidgetToggleRow(
                    label = AppStrings.get("widget_show_wind", language),
                    checked = config.showWindCompass,
                    onCheckedChange = { onConfigChange(config.copy(showWindCompass = it)) }
                )
                WidgetToggleRow(
                    label = AppStrings.get("widget_show_hourly", language),
                    checked = config.showHourlyForecast,
                    onCheckedChange = { onConfigChange(config.copy(showHourlyForecast = it)) }
                )
                WidgetToggleRow(
                    label = AppStrings.get("widget_show_alerts", language),
                    checked = config.showSevereAlerts,
                    onCheckedChange = { onConfigChange(config.copy(showSevereAlerts = it)) }
                )
            }

            // Apply button
            Button(
                onClick = {
                    savedSuccessState = true
                    onSaveSuccess()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("apply_widget_btn"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(
                    imageVector = if (savedSuccessState) Icons.Default.CheckCircle else Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (savedSuccessState) AppStrings.get("widget_saved_toast", language)
                    else AppStrings.get("widget_add_to_home", language),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun WidgetPreviewRenderer(
    weather: WeatherInfo,
    config: WidgetConfig,
    tempUnit: TemperatureUnit,
    windUnit: WindUnit,
    isTurkish: Boolean
) {
    val condition = WeatherCodeHelper.getDisplay(weather.weatherCode)

    val backgroundModifier = when (config.widgetStyle) {
        "GLASS" -> Modifier
            .background(Color(0x331E293B))
            .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(20.dp))
        "WIND_RADAR" -> Modifier
            .background(
                Brush.linearGradient(listOf(Color(0xFF0F172A), Color(0xFF164E63), Color(0xFF065F46)))
            )
        "EXTENDED" -> Modifier
            .background(
                Brush.linearGradient(listOf(Color(0xFF1E1B4B), Color(0xFF312E81), Color(0xFF1E293B)))
            )
        else -> Modifier.background(
            Brush.linearGradient(listOf(Color(0xFF0284C7), Color(0xFF0369A1), Color(0xFF075985)))
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .then(backgroundModifier)
            .padding(16.dp)
            .testTag("widget_live_preview_box")
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Widget Top Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = weather.cityName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (isTurkish) weather.weatherDescriptionTr else weather.weatherDescriptionEn,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = condition.icon,
                        contentDescription = null,
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = tempUnit.format(weather.currentTemp),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                }
            }

            // Wind & Gusts row if enabled
            if (config.showWindCompass) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black.copy(alpha = 0.25f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Air,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "${if (isTurkish) "Rüzgar" else "Wind"}: ${windUnit.format(weather.windDetails.speedKmh, isTurkish)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    }

                    Text(
                        text = "${weather.windDetails.cardinalDirectionLocalized(isTurkish)} • Bft ${weather.windDetails.beaufortScale.level}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }

            // Severe alert badge if active and enabled
            if (config.showSevereAlerts && weather.activeAlerts.isNotEmpty()) {
                val alert = weather.activeAlerts.first()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFEF4444).copy(alpha = 0.85f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (isTurkish) alert.titleTr else alert.titleEn,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun WidgetToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
