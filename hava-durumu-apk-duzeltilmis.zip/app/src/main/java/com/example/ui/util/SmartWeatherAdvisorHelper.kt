package com.example.ui.util

import com.example.data.model.SmartWeatherAdvice
import com.example.data.model.WeatherInfo

object SmartWeatherAdvisorHelper {

    fun generateAdvice(weather: WeatherInfo): SmartWeatherAdvice {
        val temp = weather.currentTemp
        val feelsLike = weather.feelsLikeTemp
        val windSpeed = weather.windDetails.speedKmh
        val windGust = weather.windDetails.gustKmh
        val weatherCode = weather.weatherCode
        val isRainy = weatherCode in listOf(51, 53, 55, 61, 63, 65, 80, 81, 82, 95, 96, 99)
        val isSnowy = weatherCode in listOf(71, 73, 75, 77, 85, 86)
        val isFoggy = weatherCode in listOf(45, 48)
        val isStormy = weatherCode in listOf(95, 96, 99) || windSpeed >= 50.0

        val roundedTemp = Math.round(temp)
        val roundedFeels = Math.round(feelsLike)
        val roundedWind = Math.round(windSpeed)
        val roundedGust = Math.round(windGust)

        // 1. Giyim Önerisi (Clothing advice)
        val (clothingTr, clothingEn, badgeCategory) = when {
            feelsLike <= 0.0 -> Triple(
                "Hava dondurucu soğuk ($roundedTemp°C, hissedilen $roundedFeels°C)! Termal içlik, kalın kaban/mont, atkı, yün bere ve su geçirmez eldiven giymeniz kesinlikle tavsiye edilir.",
                "Freezing cold ($roundedTemp°C, feels like $roundedFeels°C)! Wear heavy winter coat, thermal layers, scarf, beanie, and insulated gloves.",
                "FREEZING"
            )
            feelsLike in 0.1..9.0 -> Triple(
                "Hava oldukça soğuk ($roundedTemp°C, hissedilen $roundedFeels°C). Kalın bir kışlık mont, kazak veya polar giyin. Rüzgar soğuğuna karşı atkı almayı unutmayın.",
                "Quite cold ($roundedTemp°C, feels like $roundedFeels°C). Wear a thick winter coat, sweater, or fleece with a warm scarf.",
                "COLD"
            )
            feelsLike in 9.1..16.0 -> Triple(
                "Hava serin ($roundedTemp°C). Mevsimlik bir ceket, rüzgarlık veya kalın hırka tercih edin. Kat kat giyinmek gün içindeki değişimler için idealdir.",
                "Cool weather ($roundedTemp°C). A seasonal jacket, windbreaker, or warm cardigan is recommended.",
                "MILD"
            )
            feelsLike in 16.1..23.0 -> Triple(
                "Hava ılık ve ferah ($roundedTemp°C). Hafif bir mont veya uzun kollu tişört/gömlek tercih edebilirsiniz.",
                "Pleasant and mild ($roundedTemp°C). Light jacket, hoodie, or long-sleeve shirt is ideal.",
                "WARM"
            )
            feelsLike in 23.1..29.0 -> Triple(
                "Hava sıcak ($roundedTemp°C). Nefes alabilen pamuklu ve açık renkli kıyafetler giyin. Rahat ayakkabılar tercih edin.",
                "Warm weather ($roundedTemp°C). Wear breathable cotton and light-colored clothes.",
                "WARM"
            )
            else -> Triple(
                "Hava oldukça sıcak ve bunaltıcı ($roundedTemp°C)! İnce, bol ve açık renkli yazlık giysiler tercih edin. Güneşten korunmaya özen gösterin.",
                "Very hot ($roundedTemp°C)! Wear ultralight, loose summer clothing and seek shade.",
                "HOT"
            )
        }

        // 2. Rüzgar Analizi (Wind Analysis)
        val (windAnalysisTr, windAnalysisEn) = when {
            windSpeed >= 50.0 || windGust >= 65.0 -> Pair(
                "⚠️ Şiddetli fırtına etkisi ($roundedWind km/s rüzgar, $roundedGust km/s hamle)! Rüzgar geçirmez sert dış kabuk giysi zorunludur. Şemsiye açmayın, devrilebilecek nesnelere dikkat edin.",
                "⚠️ Gale / Storm force wind ($roundedWind km/h, gust $roundedGust km/h)! Windproof hardshell jacket is mandatory. Avoid umbrellas and watch for flying debris."
            )
            windSpeed in 30.0..49.9 -> Pair(
                "💨 Kuvvetli rüzgar ($roundedWind km/s rüzgar) esiyor. Hissedilen sıcaklığı düşürdüğü için rüzgarlık/mont giymeniz ve şapka/atkı ile başınızı korumanız önerilir.",
                "💨 Strong wind ($roundedWind km/h). Significantly reduces perceived temperature; wear a windbreaker and protect head/ears."
            )
            windSpeed in 15.0..29.9 -> Pair(
                "🍃 Canlı ve hissedilir bir esinti ($roundedWind km/s) mevcut. Yürüyüş için ferahlatıcı ancak serinlik hissi verebilir.",
                "🍃 Fresh breeze ($roundedWind km/h). Refreshing for outdoor walks but adds a slight chill."
            )
            else -> Pair(
                "☀️ Sakin ve durgun rüzgar ($roundedWind km/s). Rüzgar kaynaklı üşüme riski bulunmuyor.",
                "☀️ Calm/Light wind ($roundedWind km/h). Minimal wind chill effect."
            )
        }

        // 3. Yağış & Ekipman (Gear & Activity)
        val gearTr = mutableListOf<String>()
        val gearEn = mutableListOf<String>()

        if (feelsLike < 10.0) {
            gearTr.add("🧥 Kalın Mont / Kaban")
            gearEn.add("🧥 Heavy Coat")
        } else if (feelsLike < 18.0) {
            gearTr.add("🧥 Mevsimlik Ceket / Rüzgarlık")
            gearEn.add("🧥 Light Jacket")
        } else {
            gearTr.add("👕 Rahat Tişört")
            gearEn.add("👕 Light Shirt")
        }

        if (windSpeed >= 25.0) {
            gearTr.add("💨 Rüzgar Geçirmez Giysi")
            gearEn.add("💨 Windproof Layer")
        }

        if (isRainy || isStormy) {
            gearTr.add("☂️ Şemsiye")
            gearEn.add("☂️ Umbrella")
            gearTr.add("🥾 Su Geçirmez Ayakkabı")
            gearEn.add("🥾 Waterproof Shoes")
        }

        if (isSnowy) {
            gearTr.add("❄️ Kışlık Bot")
            gearEn.add("❄️ Snow Boots")
            gearTr.add("🧤 Kalın Eldiven")
            gearEn.add("🧤 Warm Gloves")
        }

        if (feelsLike <= 5.0) {
            gearTr.add("🧣 Atkı & Bere")
            gearEn.add("🧣 Scarf & Beanie")
        }

        if (temp >= 22.0 && !isRainy && !isSnowy) {
            gearTr.add("🕶️ Güneş Gözlüğü")
            gearEn.add("🕶️ Sunglasses")
            gearTr.add("🧴 Güneş Kremi")
            gearEn.add("🧴 Sunscreen")
            gearTr.add("💧 Su Şişesi")
            gearEn.add("💧 Water Bottle")
        }

        // 4. Aktivite Tavsiyesi (Activity suitability)
        val (activityTr, activityEn) = when {
            isStormy || windSpeed >= 50.0 -> Pair(
                "Açık hava aktiviteleri için uygun değil. Kapalı mekanları tercih edin.",
                "Not suitable for outdoor activities. Stay indoors."
            )
            isRainy -> Pair(
                "Yağış nedeniyle yürüyüş veya bisiklet için su geçirmez ekipman şarttır.",
                "Waterproof gear is required for walking or commuting."
            )
            isSnowy -> Pair(
                "Kış manzarası için güzel bir gün, kaygan zeminlere dikkat edin.",
                "Picturesque winter day, watch out for slippery pavements."
            )
            feelsLike in 15.0..26.0 && windSpeed < 30.0 -> Pair(
                "Mükemmel hava! Yürüyüş, koşu ve açık hava sporları için son derece elverişli.",
                "Perfect weather! Highly suitable for walking, jogging, and outdoor sports."
            )
            feelsLike > 30.0 -> Pair(
                "Öğle saatlerinde doğrudan güneş altında yoğun efordan kaçının.",
                "Avoid strenuous outdoor workouts during peak midday sun."
            )
            else -> Pair(
                "Gereken giyim önlemleriyle dışarı çıkılabilir.",
                "Good for outdoor plans with proper clothing layers."
            )
        }

        val titleTr = when {
            isStormy -> "⚠️ Fırtına & Hava Uyarısı"
            feelsLike <= 5.0 -> "❄️ Soğuk Hava & Kalın Giyim Tavsiyesi"
            windSpeed >= 35.0 -> "💨 Kuvvetli Rüzgar & Korunma Rehberi"
            isRainy -> "🌧️ Yağış & Ekipman Önerisi"
            temp >= 26.0 -> "☀️ Sıcak Hava & Güneş Koruması"
            else -> "✨ Akıllı Günlük Giyim & Rüzgar Önerisi"
        }

        val titleEn = when {
            isStormy -> "⚠️ Storm & Wind Advisory"
            feelsLike <= 5.0 -> "❄️ Cold Weather & Warm Clothing Advice"
            windSpeed >= 35.0 -> "💨 High Wind & Windbreaker Guide"
            isRainy -> "🌧️ Rain & Gear Recommendation"
            temp >= 26.0 -> "☀️ Warm Sun & UV Protection"
            else -> "✨ Smart Clothing & Wind Advisor"
        }

        val summaryTr = if (feelsLike <= 10.0) {
            "Hava soğuk ($roundedTemp°C) ve rüzgar ($roundedWind km/s) nedeniyle daha soğuk hissediliyor. Kalın giyinin!"
        } else if (windSpeed >= 35.0) {
            "Rüzgar hızı yüksek ($roundedWind km/s). Rüzgar kesici mont ve koruyucu giysiler önerilir."
        } else if (isRainy) {
            "Yağış bekleniyor. Şemsiye ve su geçirmez ayakkabınızı yanınıza almayı unutmayın."
        } else if (temp >= 25.0) {
            "Hava sıcak ve açık. İnce, ferah giyinin ve bol su için."
        } else {
            "Hava ılık ve sakin. Hafif bir ceketle rahatça dışarı çıkabilirsiniz."
        }

        val summaryEn = if (feelsLike <= 10.0) {
            "Chilly weather ($roundedTemp°C) with $roundedWind km/h wind. Bundle up with warm layers!"
        } else if (windSpeed >= 35.0) {
            "Wind speeds are strong ($roundedWind km/h). A windbreaker is recommended."
        } else if (isRainy) {
            "Rain is expected. Don't forget your umbrella and waterproof gear."
        } else if (temp >= 25.0) {
            "Warm and bright. Wear light clothes and stay hydrated."
        } else {
            "Mild and pleasant. A light jacket will keep you comfortable."
        }

        return SmartWeatherAdvice(
            titleTr = titleTr,
            titleEn = titleEn,
            summaryTr = summaryTr,
            summaryEn = summaryEn,
            clothingAdviceTr = clothingTr,
            clothingAdviceEn = clothingEn,
            windAnalysisTr = windAnalysisTr,
            windAnalysisEn = windAnalysisEn,
            activityAdviceTr = activityTr,
            activityAdviceEn = activityEn,
            recommendedGearTr = gearTr,
            recommendedGearEn = gearEn,
            isAlertUrgent = isStormy || feelsLike <= -5.0 || windSpeed >= 55.0,
            badgeCategory = badgeCategory
        )
    }
}
