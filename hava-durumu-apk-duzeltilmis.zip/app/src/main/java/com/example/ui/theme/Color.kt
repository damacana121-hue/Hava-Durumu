package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val SkyBlueLight = Color(0xFF0284C7)
val SkyBlueDark = Color(0xFF0369A1)
val SkyBlueContainer = Color(0xFFE0F2FE)
val OnSkyBlueContainer = Color(0xFF075985)

val AccentAmberLight = Color(0xFFF59E0B)
val AccentAmberDark = Color(0xFFD97706)
val AccentAmberContainer = Color(0xFFFEF3C7)

val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceCard = Color(0xFF1E293B)
val DarkSurfaceElevated = Color(0xFF334155)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)

val PrimaryBlue = Color(0xFF0284C7)
val PrimaryBlueDark = Color(0xFF38BDF8)

val WeatherStormy = Color(0xFF64748B)
val WeatherWarningOrange = Color(0xFFEA580C)
val WeatherDangerRed = Color(0xFFDC2626)
val WeatherSuccessGreen = Color(0xFF16A34A)

// Glass effect colors
val GlassCardDark = Color(0x331E293B)
val GlassBorderDark = Color(0x33FFFFFF)
val GlassCardLight = Color(0xEEFFFFFF)
val GlassBorderLight = Color(0x220284C7)
