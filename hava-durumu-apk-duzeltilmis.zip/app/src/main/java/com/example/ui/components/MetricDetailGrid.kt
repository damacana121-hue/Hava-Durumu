package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.TemperatureUnit
import com.example.data.model.WeatherInfo
import com.example.ui.localization.AppStrings

@Composable
fun MetricDetailGrid(
    weather: WeatherInfo,
    tempUnit: TemperatureUnit,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val isTr = language == AppLanguage.TURKISH
    val todayForecast = weather.dailyForecasts.firstOrNull()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Row 1: Feels Like & Humidity
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricTile(
                title = AppStrings.get("feels_like", language),
                value = tempUnit.format(weather.feelsLikeTemp),
                subtitle = if (isTr) "Gerçek sıcaklık ile benzer" else "Similar to actual temp",
                icon = Icons.Default.Thermostat,
                iconTint = Color(0xFFF97316),
                modifier = Modifier.weight(1f)
            )

            MetricTile(
                title = AppStrings.get("humidity", language),
                value = "${weather.humidity}%",
                subtitle = if (weather.humidity > 70) (if (isTr) "Yüksek nem" else "High humidity") else (if (isTr) "Normal nem" else "Comfortable"),
                icon = Icons.Default.WaterDrop,
                iconTint = Color(0xFF0284C7),
                modifier = Modifier.weight(1f)
            )
        }

        // Row 2: UV Index & Pressure
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val uv = todayForecast?.uvIndex ?: 4.5
            val uvLabel = when {
                uv <= 2 -> if (isTr) "Düşük (Güvenli)" else "Low (Safe)"
                uv <= 5 -> if (isTr) "Orta (Önlem al)" else "Moderate"
                uv <= 7 -> if (isTr) "Yüksek (Güneş kremi)" else "High (Protection)"
                else -> if (isTr) "Çok Yüksek (Gölgede kal)" else "Very High"
            }

            MetricTile(
                title = AppStrings.get("uv_index", language),
                value = String.format("%.1f", uv),
                subtitle = uvLabel,
                icon = Icons.Default.WbSunny,
                iconTint = Color(0xFFEAB308),
                modifier = Modifier.weight(1f)
            )

            MetricTile(
                title = AppStrings.get("pressure", language),
                value = "${Math.round(weather.surfacePressureHpa)} hPa",
                subtitle = if (weather.surfacePressureHpa >= 1013) (if (isTr) "Yüksek basınç" else "High pressure") else (if (isTr) "Alçak basınç" else "Low pressure"),
                icon = Icons.Default.Compress,
                iconTint = Color(0xFF8B5CF6),
                modifier = Modifier.weight(1f)
            )
        }

        // Row 3: Sunrise & Sunset
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricTile(
                title = AppStrings.get("sunrise", language),
                value = todayForecast?.sunrise ?: "06:15",
                subtitle = if (isTr) "Şafak vakti" else "Dawn",
                icon = Icons.Default.WbTwilight,
                iconTint = Color(0xFFF59E0B),
                modifier = Modifier.weight(1f)
            )

            MetricTile(
                title = AppStrings.get("sunset", language),
                value = todayForecast?.sunset ?: "19:48",
                subtitle = if (isTr) "Akşam alacakaranlık" else "Dusk",
                icon = Icons.Default.WbTwilight,
                iconTint = Color(0xFF6366F1),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun MetricTile(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .testTag("metric_tile_${title.lowercase().replace(" ", "_")}")
            .semantics {
                contentDescription = "$title: $value, $subtitle"
            },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(iconTint.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }

            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
        }
    }
}
