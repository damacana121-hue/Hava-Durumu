package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.TemperatureUnit
import com.example.data.model.WeatherInfo
import com.example.data.model.WidgetConfig
import com.example.data.model.WindUnit
import com.example.ui.components.WidgetCustomizerCard
import com.example.ui.localization.AppStrings
import kotlinx.coroutines.launch

@Composable
fun WidgetsStudioScreen(
    weather: WeatherInfo,
    config: WidgetConfig,
    tempUnit: TemperatureUnit,
    windUnit: WindUnit,
    language: AppLanguage,
    snackbarHostState: SnackbarHostState,
    onConfigChange: (WidgetConfig) -> Unit,
    modifier: Modifier = Modifier
) {
    val isTr = language == AppLanguage.TURKISH
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("widgets_studio_screen_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title
        item {
            Text(
                text = AppStrings.get("tab_widgets", language),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        // Main Widget Customizer
        item {
            WidgetCustomizerCard(
                weather = weather,
                config = config,
                tempUnit = tempUnit,
                windUnit = windUnit,
                language = language,
                onConfigChange = onConfigChange,
                onSaveSuccess = {
                    scope.launch {
                        snackbarHostState.showSnackbar(AppStrings.get("widget_saved_toast", language))
                    }
                }
            )
        }

        // Widget Usage Instructions
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("widget_instructions_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = if (isTr) "Widget Nasıl Eklenir?" else "How to add to Home Screen?",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Text(
                        text = if (isTr) "1. Telefonunuzun ana ekranında boş bir alana uzun basın.\n2. Açılan menüden 'Widget'lar' seçeneğini belirleyin.\n3. 'Hava Durumu' uygulamasını bularak özelleştirdiğiniz boyuttaki widget'ı ana ekranınıza sürükleyin."
                        else "1. Long press on any empty space on your Android home screen.\n2. Tap 'Widgets' from the popup menu.\n3. Find 'Hava Durumu' (Weather) and drag your customized widget to your home screen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
