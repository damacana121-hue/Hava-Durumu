package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material.icons.outlined.Cloud
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.Widgets
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.ui.localization.AppStrings
import com.example.ui.screens.AlertsScreen
import com.example.ui.screens.LocationsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WeatherDashboardScreen
import com.example.ui.screens.WidgetsStudioScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.WeatherUiState
import com.example.ui.viewmodel.WeatherViewModel

enum class MainNavTab(
    val titleKey: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    TODAY("tab_today", Icons.Filled.WbSunny, Icons.Outlined.WbSunny),
    LOCATIONS("tab_locations", Icons.Filled.LocationOn, Icons.Outlined.LocationOn),
    ALERTS("tab_alerts", Icons.Filled.Notifications, Icons.Outlined.Notifications),
    WIDGETS("tab_widgets", Icons.Filled.Widgets, Icons.Outlined.Widgets),
    SETTINGS("tab_settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

class MainActivity : ComponentActivity() {

    private val viewModel: WeatherViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val language by viewModel.appLanguage.collectAsStateWithLifecycle()

            MyApplicationTheme(themeMode = themeMode) {
                MainAppContent(
                    viewModel = viewModel,
                    language = language
                )
            }
        }
    }
}

@Composable
fun MainAppContent(
    viewModel: WeatherViewModel,
    language: AppLanguage
) {
    val context = LocalContext.current
    var selectedTab by rememberSaveable { mutableStateOf(MainNavTab.TODAY) }
    val snackbarHostState = remember { SnackbarHostState() }

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val currentLocation by viewModel.currentLocation.collectAsStateWithLifecycle()
    val savedLocations by viewModel.savedLocations.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()
    val alertHistory by viewModel.alertHistory.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val tempUnit by viewModel.tempUnit.collectAsStateWithLifecycle()
    val windUnit by viewModel.windUnit.collectAsStateWithLifecycle()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsStateWithLifecycle()
    val windAlertThreshold by viewModel.windAlertThreshold.collectAsStateWithLifecycle()
    val widgetConfig by viewModel.widgetConfig.collectAsStateWithLifecycle()
    val cloudSyncStatus by viewModel.cloudSyncStatus.collectAsStateWithLifecycle()

    // Request Notification permission on Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("main_bottom_nav_bar")
            ) {
                MainNavTab.entries.forEach { tab ->
                    val isSelected = selectedTab == tab
                    val label = AppStrings.get(tab.titleKey, language)

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            if (tab == MainNavTab.ALERTS && (uiState as? WeatherUiState.Success)?.weather?.activeAlerts?.isNotEmpty() == true) {
                                BadgedBox(badge = { Badge { Text("!") } }) {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = label
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                    contentDescription = label
                                )
                            }
                        },
                        label = { Text(text = label) },
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (val state = uiState) {
                is WeatherUiState.Loading -> {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }
                is WeatherUiState.Error -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudOff,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(48.dp)
                                )
                                Text(
                                    text = state.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Button(
                                    onClick = { viewModel.loadWeatherForCurrentLocation() },
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(AppStrings.get("retry", language))
                                }
                            }
                        }
                    }
                }
                is WeatherUiState.Success -> {
                    AnimatedContent(
                        targetState = selectedTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "tabContentTransition"
                    ) { targetTab ->
                        when (targetTab) {
                            MainNavTab.TODAY -> {
                                WeatherDashboardScreen(
                                    weather = state.weather,
                                    isRefreshing = state.isRefreshing,
                                    tempUnit = tempUnit,
                                    windUnit = windUnit,
                                    language = language,
                                    onRefresh = { viewModel.loadWeatherForCurrentLocation(isRefresh = true) },
                                    onSearchClick = { selectedTab = MainNavTab.LOCATIONS },
                                    onAlertClick = { selectedTab = MainNavTab.ALERTS }
                                )
                            }
                            MainNavTab.LOCATIONS -> {
                                LocationsScreen(
                                    currentLocation = currentLocation,
                                    savedLocations = savedLocations,
                                    searchResults = searchResults,
                                    isSearching = isSearching,
                                    language = language,
                                    onSearchQueryChange = { viewModel.searchCities(it) },
                                    onSelectLocation = { loc ->
                                        viewModel.selectLocation(loc)
                                        selectedTab = MainNavTab.TODAY
                                    },
                                    onSaveLocation = { viewModel.addLocationToFavorites(it) },
                                    onRemoveLocation = { viewModel.removeSavedLocation(it) },
                                    onPopularCityClick = { city ->
                                        viewModel.selectLocation(city)
                                        selectedTab = MainNavTab.TODAY
                                    }
                                )
                            }
                            MainNavTab.ALERTS -> {
                                AlertsScreen(
                                    currentLocation = currentLocation,
                                    notificationsEnabled = notificationsEnabled,
                                    windAlertThresholdKmh = windAlertThreshold,
                                    alertHistory = alertHistory,
                                    language = language,
                                    onToggleNotifications = { viewModel.setNotificationsEnabled(it) },
                                    onWindThresholdChange = { viewModel.setWindAlertThreshold(it) },
                                    onSendTestAlert = { viewModel.sendTestSevereWeatherNotification() },
                                    onSendSmartAdviceAlert = { viewModel.sendSmartAdviceNotificationAction() }
                                )
                            }
                            MainNavTab.WIDGETS -> {
                                WidgetsStudioScreen(
                                    weather = state.weather,
                                    config = widgetConfig,
                                    tempUnit = tempUnit,
                                    windUnit = windUnit,
                                    language = language,
                                    snackbarHostState = snackbarHostState,
                                    onConfigChange = { viewModel.updateWidgetConfig(it) }
                                )
                            }
                            MainNavTab.SETTINGS -> {
                                SettingsScreen(
                                    themeMode = themeMode,
                                    language = language,
                                    tempUnit = tempUnit,
                                    windUnit = windUnit,
                                    cloudSyncStatus = cloudSyncStatus,
                                    snackbarHostState = snackbarHostState,
                                    onThemeChange = { viewModel.setThemeMode(it) },
                                    onLanguageChange = { viewModel.setLanguage(it) },
                                    onTempUnitChange = { viewModel.setTempUnit(it) },
                                    onWindUnitChange = { viewModel.setWindUnit(it) },
                                    onCloudSync = { viewModel.performCloudSync() },
                                    onCloudRestore = { viewModel.restoreFromCloud() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
