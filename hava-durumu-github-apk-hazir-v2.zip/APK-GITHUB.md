# APK oluşturma

Bu proje AGP 9.1.1 kullanıyor. GitHub Actions workflow'u JDK 17 ve Gradle 9.3.1 ile debug APK üretir.

GitHub'da:
1. Actions
2. Build APK
3. Run workflow

Build başarılı olunca `Hava-Durumu-debug-apk` artifact'ını açıp APK'yı indirebilirsin.
